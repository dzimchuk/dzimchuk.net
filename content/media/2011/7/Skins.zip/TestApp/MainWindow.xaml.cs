﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Dzimchuk.Utils.Skinner;
using System.Diagnostics;

namespace TestApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<SkinDescription> _skins;
        private readonly ISkinManager _skinManager;
        
        public MainWindow()
        {
            InitializeComponent();

            _skins = new ObservableCollection<SkinDescription>();
            _skins.Add(new SkinDescription("-", new Uri("non-existing", UriKind.Relative)));

            listSkins.ItemsSource = _skins;

            _skinManager = SkinManagerFactory.GetSkinManager();
            _skinManager.SkinFound += new EventHandler<SkinFoundEventArgs>(_skinManager_SkinFound);

            _skinManager.Scan();
        }

        private void _skinManager_SkinFound(object sender, SkinFoundEventArgs e)
        {
            _skins.Add(e.SkinDescription);
        }

        private void listSkins_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Stopwatch watch = new Stopwatch();
            try
            {
                var skinDescription = (SkinDescription)listSkins.SelectedItem;
                if ("-" == skinDescription.Name)
                {
                    _skinManager.UnloadCurrentSkin();
                }
                else
                {
                    watch.Start();
                    _skinManager.Load(skinDescription);
                    watch.Stop();
                //    MessageBox.Show(string.Format("Skin was loaded in {0}", watch.Elapsed));
                }
            }
            catch (LoadSkinException loadException)
            {
                MessageBox.Show(loadException.ToString());
            }
            finally
            {
                watch.Stop();
            }
        }
    }
}
