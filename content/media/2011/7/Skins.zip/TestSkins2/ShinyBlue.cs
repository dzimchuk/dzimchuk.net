﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Dzimchuk.Utils.Skinner;

namespace TestSkins2
{
    [Export(typeof(ISkin))]
    public class ShinyBlue : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Shiny Blue", new Uri("TestSkins2;v1.0.0.0;component/Skins/ShinyBlue.xaml", UriKind.Relative));
        }
    }
}
