﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Dzimchuk.Utils.Skinner;

namespace TestSkins2
{
    [Export(typeof(ISkin))]
    public class WhistlerBlue : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Whistler Blue", new Uri("/TestSkins2;component/Skins/WhistlerBlue.xaml", UriKind.Relative));
        }
    }
}
