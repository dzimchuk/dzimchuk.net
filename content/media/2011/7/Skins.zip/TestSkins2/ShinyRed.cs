﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Dzimchuk.Utils.Skinner;

namespace TestSkins2
{
    [Export(typeof(ISkin))]
    public class ShinyRed : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Shiny Red", new Uri("/TestSkins2;component/Skins/ShinyRed.xaml", UriKind.Relative));
        }
    }
}
