﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Dzimchuk.Utils.Skinner;

namespace TestSkins1
{
    [Export(typeof(ISkin))]
    public class BureauBlue : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Bureau Blue", new Uri("/Skins/BureauBlue.xaml", UriKind.Relative));
        }
    }
}
