﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Dzimchuk.Utils.Skinner;

namespace TestSkins1
{
    [Export(typeof(ISkin))]
    public class ExpressionDark : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Expression Dark", new Uri("Skins/ExpressionDark.xaml", UriKind.Relative));
        }
    }
}
