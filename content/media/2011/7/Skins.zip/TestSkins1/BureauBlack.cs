﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dzimchuk.Utils.Skinner;
using System.ComponentModel.Composition;

namespace TestSkins1
{
    [Export(typeof(ISkin))]
    public class BureauBlack : ISkin
    {
        public SkinDescription GetDescription()
        {
            return new SkinDescription("Bureau Black", new Uri("/Skins/BureauBlack.xaml", UriKind.Relative));
        }
    }
}
