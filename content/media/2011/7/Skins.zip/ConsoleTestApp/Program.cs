﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dzimchuk.Utils.Skinner;
using System.Threading;
using System.Diagnostics;
using System.IO;

namespace ConsoleTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            CopySkins();
            
            CountdownEvent cde = new CountdownEvent(707);
            
            ISkinManager manager = SkinManagerFactory.GetSkinManager();
            manager.SkinFound += (sender, arguments) =>
                {
                    Console.WriteLine("Thread: {0}, skin name: {1}, Uri: {2}", Thread.CurrentThread.ManagedThreadId, 
                        arguments.SkinDescription.Name, arguments.SkinDescription.ResourceDictionayPackUri);
                    cde.Signal();
                };
            manager.ScanError += (sender, arguments) =>
                {
                    Console.WriteLine("Thread: {0}, Error: {1}", Thread.CurrentThread.ManagedThreadId,
                        arguments.Error);
                    cde.Signal();
                };

            Stopwatch watch = new Stopwatch();
            watch.Start();

            manager.Scan();

            cde.Wait();
            watch.Stop();
            Console.WriteLine("Elapsed: {0}, thread: {1}", watch.Elapsed, Thread.CurrentThread.ManagedThreadId);
            Console.ReadLine();
        }

        static void CopySkins()
        {
            string dir = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "skins");
            if (!Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            string skin1 = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "TestSkins1.dll");
            for (int i = 0; i < 100; i++)
            {
                File.Copy(skin1, Path.Combine(dir, string.Format("TestSkins1_{0}.dll", i)), true);
            }

            string skin2 = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "TestSkins2.dll");
            for (int i = 0; i < 100; i++)
            {
                File.Copy(skin2, Path.Combine(dir, string.Format("TestSkins2_{0}.dll", i)), true);
            }
        }
    }
}
