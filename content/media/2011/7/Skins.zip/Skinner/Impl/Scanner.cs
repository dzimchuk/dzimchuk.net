﻿/* ****************************************************************************
 *
 * Copyright (c) Andrei Dzimchuk. All rights reserved.
 *
 * This software is subject to the Microsoft Public License (Ms-PL). 
 * A copy of the license can be found in the license.htm file included 
 * in this distribution.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.IO;
using System.Text.RegularExpressions;

namespace Dzimchuk.Utils.Skinner.Impl
{
    internal class Scanner : MarshalByRefObject
    {
        public static void Scan(Action<SkinDescription> callback, Action<Exception> errorCallback)
        {
            AppDomain domain = null;

            try
            {
                domain = AppDomain.CreateDomain("Skinner.Scanner.Domain");
                Scanner scanner = (Scanner)domain.CreateInstanceAndUnwrap(Assembly.GetExecutingAssembly().FullName,
                                    typeof(Scanner).FullName);

                Scanner thisDomainScanner = new Scanner();
                thisDomainScanner._callback = callback;
                thisDomainScanner._errorCallback = errorCallback;

                scanner.SkinFound += thisDomainScanner.OnSkinFound;
                scanner.ScanError += thisDomainScanner.OnScanError;

                scanner.Scan();
            }
            catch(Exception e)
            { // it happens on a thread from the pool and if not caught it's going to ruin the application
              // it may happen for a variety of reasons like the 'skins' directory wasn't found

                errorCallback(e);
            } 
            finally
            {
                if (domain != null)
                    AppDomain.Unload(domain);
            }
        }

        private void OnSkinFound(object sender, SkinFoundEventArgs args)
        {
            _callback(args.SkinDescription);
        }

        private void OnScanError(object sender, ScanErrorEventArgs args)
        {
            _errorCallback(args.Error);
        }

        private Action<SkinDescription> _callback;
        private Action<Exception> _errorCallback;

        private event EventHandler<SkinFoundEventArgs> SkinFound;
        private event EventHandler<ScanErrorEventArgs> ScanError;
        private const string PACK_URI_FORMAT = "/{0};component/{1}";

        #pragma warning disable 0649 // a 'variable is never assigned to' warning
        [ImportMany]
        private IEnumerable<Lazy<ISkin>> _foundSkins;
        #pragma warning restore 0649

        private void Scan()
        {
            using (AggregateCatalog aggregateCatalog = new AggregateCatalog())
            {
                aggregateCatalog.Catalogs.Add(new AssemblyCatalog(typeof(Scanner).Assembly));
                aggregateCatalog.Catalogs.Add(new DirectoryCatalog(AppDomain.CurrentDomain.SetupInformation.ApplicationBase));
                aggregateCatalog.Catalogs.Add(new DirectoryCatalog(Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "skins")));

                using (CompositionContainer container = new CompositionContainer(aggregateCatalog))
                {
                    container.ComposeParts(this);

                    if (SkinFound != null)
                    {
                        foreach (var skin in _foundSkins)
                        {
                            try
                            {
                                var description = skin.Value.GetDescription();
                                var innerPart = GetInnerRelativePart(description.ResourceDictionayPackUri.ToString());

                                if (string.IsNullOrEmpty(innerPart))
                                    throw new ArgumentException(string.Format("Invalid relative resource Uri: {0}", description.ResourceDictionayPackUri));

                                Assembly assembly = skin.Value.GetType().Assembly;
                                description = new SkinDescription(description.Name,
                                    new Uri(string.Format(PACK_URI_FORMAT, assembly.GetName().Name, innerPart), UriKind.Relative));

                                SkinFound(this, new SkinFoundEventArgs(description));

                            }
                            catch(Exception e)
                            {
                                ScanError(this, new ScanErrorEventArgs(e));   
                            }

                        }
                    }
                }
            }
        }

        private readonly Regex _regexComponent = new Regex(@";component/(?<relative>.+\.xaml)$");
        private readonly Regex _regexInner = new Regex(@"^/(?<relative>.+\.xaml)$");
        private readonly Regex _regexInner2 = new Regex(@"^(?<relative>[^/].+\.xaml)$");
        private string GetInnerRelativePart(string sourceUri)
        {
            string ret = Match(sourceUri, _regexComponent);
            
            if (ret == null)
                ret = Match(sourceUri, _regexInner);

            if (ret == null)
                ret = Match(sourceUri, _regexInner2);

            return ret;
        }

        private string Match(string sourceUri, Regex regex)
        {
            Match m = regex.Match(sourceUri);
            return m.Success ? m.Groups["relative"].Value : null;
        }
    }
}
