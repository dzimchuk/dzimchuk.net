﻿/* ****************************************************************************
 *
 * Copyright (c) Andrei Dzimchuk. All rights reserved.
 *
 * This software is subject to the Microsoft Public License (Ms-PL). 
 * A copy of the license can be found in the license.htm file included 
 * in this distribution.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading;
using System.Reflection;
using System.Text.RegularExpressions;
using System.IO;

namespace Dzimchuk.Utils.Skinner.Impl
{
    /// <summary>
    /// It's not a thread-safe manager. It should be called from the UI thread.
    /// It is designed to be a singleton.
    /// </summary>
    internal class SkinManager : ISkinManager
    {
        private ResourceDictionary _currentSkinResourceDictionary;
        private readonly Regex _regexAssemblyName = new Regex(@"^(?<name>.+),.+$");
        private readonly Regex _regexAssemblyResources = new Regex(@"^[^\.]+\.resources");

        public event EventHandler<SkinFoundEventArgs> SkinFound;
        public event EventHandler<ScanErrorEventArgs> ScanError;

        public SkinManager()
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
                {
                    return ResolveAssembly(args.Name);
                };
        }

        public void Scan()
        {
            ThreadPool.QueueUserWorkItem(DoScan);
        }

        private void DoScan(object state)
        {
            Scanner.Scan(
                skinDescription =>
                {
                    RaiseSkinFound(skinDescription);
                },
                error =>
                {
                    RaiseScanError(error);
                });
        }

        private void RaiseSkinFound(SkinDescription skinDescription)
        {
            if (SkinFound != null)
            {
                var args = new SkinFoundEventArgs(skinDescription);
                if (Application.Current == null)
                {
                    SkinFound(this, args);
                }
                else
                {
                    Application.Current.Dispatcher.BeginInvoke((ThreadStart)delegate()
                    {
                        SkinFound(this, args);
                    });
                }
            }
        }

        private void RaiseScanError(Exception error)
        {
            if (ScanError != null)
            {
                var args = new ScanErrorEventArgs(error);
                if (Application.Current == null)
                {
                    ScanError(this, args);
                }
                else
                {
                    Application.Current.Dispatcher.BeginInvoke((ThreadStart)delegate()
                    {
                        ScanError(this, args);
                    });
                }
            }
        }

        private Assembly ResolveAssembly(string name)
        {
            Assembly assembly = null;
            
            try
            {
                string assemblyName = GetAssemblyFileName(name);
                if (!string.IsNullOrEmpty(assemblyName))
                    assembly = Assembly.LoadFrom(GetAssemblyFileName(name));
            }
            catch { }

            return assembly;
        }

        private string GetAssemblyFileName(string name)
        {
            if (_regexAssemblyResources.IsMatch(name))
                return null; // ignore additional requests for AssemblyName.resources
            
            string assmeblyName = name;
            Match m = _regexAssemblyName.Match(name);
            if (m.Success)
                assmeblyName = m.Groups["name"].Value;

            // try to find an assembly in the 'skins' subdirectory
            string dir = Path.Combine(AppDomain.CurrentDomain.SetupInformation.ApplicationBase, "skins");

            string assumedAssembly = Path.Combine(dir, string.Format("{0}.dll", assmeblyName));

            if (!File.Exists(assumedAssembly))
            {
                try
                {
                    var matchedFiles = Directory.GetFiles(dir, string.Format("{0}.*", assmeblyName));
                    if (matchedFiles.Length > 0)
                        assumedAssembly = matchedFiles[0];
                }
                catch { }
            }

            return assumedAssembly;
        }

        public void Load(SkinDescription skinDescription)
        {
            if (Application.Current == null)
                return;

            try
            {
                var resourceDictionary = (ResourceDictionary)Application.LoadComponent(skinDescription.ResourceDictionayPackUri);
                
                UnloadCurrentSkin();
                Application.Current.Resources.MergedDictionaries.Add(resourceDictionary);
                _currentSkinResourceDictionary = resourceDictionary;
            }
            catch (Exception e)
            {
                throw new LoadSkinException(skinDescription, e);
            }
        }

        public void UnloadCurrentSkin()
        {
            if (Application.Current != null && _currentSkinResourceDictionary != null)
            {
                Application.Current.Resources.MergedDictionaries.Remove(_currentSkinResourceDictionary);
                _currentSkinResourceDictionary = null;
            }
        }
    }
}
