﻿/* ****************************************************************************
 *
 * Copyright (c) Andrei Dzimchuk. All rights reserved.
 *
 * This software is subject to the Microsoft Public License (Ms-PL). 
 * A copy of the license can be found in the license.htm file included 
 * in this distribution.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dzimchuk.Utils.Skinner.Impl;

namespace Dzimchuk.Utils.Skinner
{
    public static class SkinManagerFactory
    {
        private static readonly Lazy<SkinManager> _skinManager = new Lazy<SkinManager>(true);

        public static ISkinManager GetSkinManager()
        {
            return _skinManager.Value;
        }
    }
}
