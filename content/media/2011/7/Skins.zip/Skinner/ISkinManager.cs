﻿/* ****************************************************************************
 *
 * Copyright (c) Andrei Dzimchuk. All rights reserved.
 *
 * This software is subject to the Microsoft Public License (Ms-PL). 
 * A copy of the license can be found in the license.htm file included 
 * in this distribution.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Dzimchuk.Utils.Skinner
{
    /// <summary>
    /// A contract for a Skin Manager.
    /// Skin Manager is an entry point for a WPF application to the skinner library.
    /// Through this interface it is possible to discover available skins, load and unload them.
    /// 
    /// The manager is expected to be called from UI thread and is not guaranteed to be thread-safe.
    /// </summary>
    public interface ISkinManager
    {
        /// <summary>
        /// Fires when a new skin has been discovered. Applications should subscribe
        /// to this event to receive skin descriptions that they can use to load skins.
        /// 
        /// The event is fired on the UI thread if Application is available.
        /// </summary>
        event EventHandler<SkinFoundEventArgs> SkinFound;
        
        /// <summary>
        /// Notifies a subscriber of any errors that occured while the scan was in progress.
        /// The error event is not fatal and doesn't abort scanning. It's primarily for notification
        /// purpose only.
        /// </summary>
        event EventHandler<ScanErrorEventArgs> ScanError;

        /// <summary>
        /// Scan for skins asynchronously using a separate domain.
        /// The domain will be unloaded once the scanning is finished.
        /// </summary>
        void Scan();

        /// <summary>
        /// Load a skin.
        /// If there is a previously loaded skin it will be unloaded first.
        /// </summary>
        /// <param name="skinDescription">A description of the skin to load.</param>
        void Load(SkinDescription skinDescription);

        /// <summary>
        /// Unload a skin that has been loaded with Load(SkinDescription) before.
        /// If no skin has been loaded, the method does nothing.
        /// </summary>
        void UnloadCurrentSkin();
    }
}
