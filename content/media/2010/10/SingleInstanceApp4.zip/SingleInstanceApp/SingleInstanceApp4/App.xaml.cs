﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using SingleInstanceApp4.Util;
using System.Diagnostics;

namespace SingleInstanceApp4
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private readonly Guid _appGuid = new Guid("{C307A02B-6F41-4996-B330-97045F4A07BC}");

        protected override void OnStartup(StartupEventArgs e)
        {
            SingleInstance si = new SingleInstance(_appGuid);
            si.ArgsRecieved += new SingleInstance.ArgsHandler(si_ArgsRecieved);
            si.Run(() =>
            {
                new MainWindow().Show();
                return this.MainWindow;
            }, e.Args);

            // just to output our process id:
            if (this.MainWindow != null)
                this.MainWindow.Content = string.Format("Process id: {0}\n", Process.GetCurrentProcess().Id);
        }

        private void si_ArgsRecieved(string[] args)
        {
            if (args.Length > 0)
                this.MainWindow.Content += string.Format("Recieved args: {0}\n", args.Aggregate((all, arg) => all += (" " + arg)));
        }
    }
}
