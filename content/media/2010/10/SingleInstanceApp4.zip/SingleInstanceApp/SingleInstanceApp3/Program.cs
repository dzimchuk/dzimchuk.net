﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SingleInstanceApp3
{
    class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            WindowsFormsApp wrapper = new WindowsFormsApp();
            wrapper.Run(args);
        }
    }
}
