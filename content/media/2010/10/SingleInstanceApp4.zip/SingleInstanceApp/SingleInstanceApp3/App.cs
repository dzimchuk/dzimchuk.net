﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace SingleInstanceApp3
{
    class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            MainWindow window = new MainWindow();
            window.Show();
        }
        
        public void ProcessArguments(string[] args)
        {
            this.MainWindow.Content += string.Format("Recieved args: {0}\n", args.Aggregate((all, arg) => all += (" " + arg)));
        }
    }
}
