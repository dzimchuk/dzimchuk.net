﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Windows;

namespace SingleInstanceApp2.Util
{
    [ServiceContract]
    interface ISingleInstanceService
    {
        [OperationContract(IsOneWay=true)]
        void BringToFront(Guid appGuid);

        [OperationContract(IsOneWay=true)]
        void ProcessArguments(Guid appGuid, string[] args);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession, 
        ConcurrencyMode=ConcurrencyMode.Single, 
        UseSynchronizationContext=true)]
    class SingleInstanceService : ISingleInstanceService, IDisposable
    {
        private Action<Guid> bringToFrontCallback;
        private Action<Guid, string[]> processArgsCallback;

        public SingleInstanceService()
        {
        }

        public SingleInstanceService(Action<Guid> bringToFrontCallback, 
                                     Action<Guid, string[]> processArgsCallback)
        {
            this.bringToFrontCallback = bringToFrontCallback;
            this.processArgsCallback = processArgsCallback;
        }
        
        public void BringToFront(Guid appGuid)
        {
            bringToFrontCallback(appGuid);
        }

        public void ProcessArguments(Guid appGuid, string[] args)
        {
            processArgsCallback(appGuid, args);
        }

        public void Dispose()
        {
            bringToFrontCallback = null;
            processArgsCallback = null;
        }
    }
}
