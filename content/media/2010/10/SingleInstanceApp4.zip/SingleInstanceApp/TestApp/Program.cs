﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                Console.WriteLine("Usage: TestApp <executable>");
                return;
            }

            Program prog = new Program();
            prog.Go(args[0]);
        }

        private void Go(string executable)
        {
            DateTime dt = DateTime.Now;
            for (int i = 0; i < 300; i++)
            {
                StartProcess(executable, string.Format("arg{0}", i));
            }
            Console.WriteLine("Running time: {0}", DateTime.Now.Subtract(dt));
        }

        private void StartProcess(string executable, string arg)
        {
            try
            {
                Process.Start(executable, arg);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
