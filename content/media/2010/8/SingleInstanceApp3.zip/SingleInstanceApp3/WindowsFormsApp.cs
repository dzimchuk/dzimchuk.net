﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SingleInstanceApp3
{
    class WindowsFormsApp : 
        Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase
    {
        private App _wpfApp;
        
        public WindowsFormsApp()
        {
            // enable Single Instance behavior
            IsSingleInstance = true;
        }

        protected override bool OnStartup(
            Microsoft.VisualBasic.ApplicationServices.StartupEventArgs e)
        {
            // we are here when the 1st instance starts up
            // start the WPF app
            _wpfApp = new App();
            _wpfApp.Run();

            return false;
        }

        protected override void OnStartupNextInstance(
            Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs e)
        {
            if (e.CommandLine.Count > 0)
            {
                _wpfApp.ProcessArguments(e.CommandLine.ToArray());
            }
        }
    }
}
