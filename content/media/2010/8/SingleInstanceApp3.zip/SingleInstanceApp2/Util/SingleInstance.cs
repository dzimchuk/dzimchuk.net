﻿using System;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Threading;
using System.Windows;

namespace SingleInstanceApp2.Util
{
    class SingleInstance : IDisposable, IInstanceProvider, IEndpointBehavior
    {
        public delegate void ArgsHandler(string[] args);

        public event ArgsHandler ArgsRecieved;
        
        private readonly Guid _appGuid;
        private readonly string _assemblyName;

        private Mutex _mutex;
        private bool _owned;
        private Window _window;
        private ServiceHost _host;

        public SingleInstance(Guid appGuid)
        {
            _appGuid = appGuid;
            _assemblyName = Assembly.GetExecutingAssembly().GetName().Name;

            _mutex = new Mutex(true, _assemblyName + _appGuid, out _owned);
        }

        public void Dispose()
        {
            if (_owned) // always release a mutex if you own it
            {
                _owned = false;
                _mutex.ReleaseMutex();
            }

            if (_host != null)
            {
                CloseCommunicationObject(_host);
                _host = null; // to be on the safe side
            }
        }

        public void Run(Func<Window> showWindow, string[] args)
        {
            if (_owned)
            {
                // show the main app window
                _window = showWindow();
                // and start the service
                StartServiceHost();
            }
            else
            {
                SendCommandLineArgs(args);
                Application.Current.Shutdown();
            }
        }

        private void CloseCommunicationObject(ICommunicationObject commObject)
        {
            try
            {
                commObject.Close();
            }
            catch
            {
                commObject.Abort();
            }
        }

        private string GetAddress()
        {
            return string.Format("net.pipe://localhost/{0}{1}", _assemblyName, _appGuid);
        }

        private Binding GetBinding()
        {
            return new NetNamedPipeBinding(NetNamedPipeSecurityMode.None);
        }

        private void StartServiceHost()
        {
            try
            {
                _host = new ServiceHost(typeof(SingleInstanceService));
                ServiceEndpoint endpoint = 
                    _host.AddServiceEndpoint(typeof(ISingleInstanceService),
                                             GetBinding(),
                                             GetAddress());
                endpoint.Behaviors.Add(this);
                _host.Open();
            }
            catch
            {
                _host = null;
                // log it
            }
        }

        private void BringToFront(Guid appGuid)
        {
            if (appGuid == _appGuid)
            {
                if (_window.WindowState == WindowState.Minimized)
                    _window.WindowState = WindowState.Normal;
                _window.Activate();
            }
        }

        private void ProcessArgs(Guid appGuid, string[] args)
        {
            if (appGuid == _appGuid && ArgsRecieved != null)
            {
                ArgsRecieved(args);
            }
        }

        private void SendCommandLineArgs(string[] args)
        {
            ISingleInstanceService proxy = null;
            try
            {
                proxy = ChannelFactory<ISingleInstanceService>.CreateChannel(GetBinding(), 
                    new EndpointAddress(GetAddress()));
                proxy.BringToFront(_appGuid);
                proxy.ProcessArguments(_appGuid, args);
            }
            catch
            { // log it
            }
            finally
            {
                if (proxy != null)
                    CloseCommunicationObject(proxy as ICommunicationObject);
            }
        }

        #region IInstanceProvider
        public object GetInstance(InstanceContext instanceContext, Message message)
        {
            return new SingleInstanceService(BringToFront, ProcessArgs);
        }

        public object GetInstance(InstanceContext instanceContext)
        {
            return GetInstance(instanceContext, null);
        }

        public void ReleaseInstance(InstanceContext instanceContext, object instance)
        {
            // no disposing logic for our service
        }
        #endregion

        #region IEndpointBehavior
        public void AddBindingParameters(ServiceEndpoint endpoint, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyClientBehavior(ServiceEndpoint endpoint, ClientRuntime clientRuntime)
        {
        }

        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            endpointDispatcher.DispatchRuntime.InstanceProvider = this;
        }

        public void Validate(ServiceEndpoint endpoint)
        {
        }
        #endregion
    }
}
