﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using SingleInstanceApp.Util;
using System.Diagnostics;
using System.Text;

namespace SingleInstanceApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private readonly Guid _appGuid = new Guid("{174ECDE3-BC6B-4AF9-8D38-539EF5E76D2B}");
        
        protected override void OnStartup(StartupEventArgs e)
        {
            SingleInstance si = new SingleInstance(_appGuid);
            si.ArgsRecieved += new SingleInstance.ArgsHandler(si_ArgsRecieved);
            si.Run(() => 
            { 
                new MainWindow().Show();
                return this.MainWindow;
            }, e.Args);

            // just to output our process id:
            if (this.MainWindow != null)
                this.MainWindow.Content = string.Format("Process id: {0}\n", Process.GetCurrentProcess().Id);
        }

        private void si_ArgsRecieved(string[] args)
        {
            if (args.Length > 0)
                this.MainWindow.Content += string.Format("Recieved args: {0}\n", args.Aggregate((all, arg) => all += (" " + arg)));
        }
    }
}
