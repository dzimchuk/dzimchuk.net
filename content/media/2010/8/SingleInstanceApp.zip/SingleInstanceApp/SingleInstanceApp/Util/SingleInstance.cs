﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;
using System.Windows;
using System.Windows.Interop;
using Dzimchuk.Native;

namespace SingleInstanceApp.Util
{
    class SingleInstance : IDisposable
    {
        public delegate void ArgsHandler(string[] args);

        public event ArgsHandler ArgsRecieved;
        
        [Serializable]
        private struct ArgsPacket
        {
            public Guid AppGuid;
            public string[] Args;
        }
        
        private readonly Guid _appGuid;

        private Mutex _mutex;
        private bool _owned;
        private HwndSource _hwndSource;
        private readonly uint UWM_ARE_YOU_ME;
        private IntPtr _hWndOther = IntPtr.Zero;

        public const int COPYDATA_TYPE_FILENAME = 0x12E208D; // my birthday if you're wondering

        public SingleInstance(Guid appGuid)
        {
            _appGuid = appGuid;
            string asssemblyName = Assembly.GetExecutingAssembly().GetName().Name;

            _mutex = new Mutex(true, asssemblyName + _appGuid, out _owned);
            UWM_ARE_YOU_ME = WindowsManagement.RegisterWindowMessage(asssemblyName + appGuid);
            
            if (!_owned)
                WindowsManagement.EnumWindows(new WindowsManagement.EnumWindowsProc(SearchCallback), IntPtr.Zero);
        }

        private int SearchCallback(IntPtr hWnd, IntPtr lParam)
        {
            int result;
            int ok = WindowsManagement.SendMessageTimeout(hWnd,
                (int)UWM_ARE_YOU_ME,
                IntPtr.Zero, IntPtr.Zero,
                WindowsManagement.SMTO_BLOCK | WindowsManagement.SMTO_ABORTIFHUNG,
                100, out result);
            if (ok == 0)
                return 1; // ignore this and continue
            if (result == (int)UWM_ARE_YOU_ME)
            { // found it
                _hWndOther = hWnd;
                return 0; // stop search
            }
            return 1; // continue
        }

        public void Dispose()
        {
            if (_owned) // always release a mutex if you own it
            {
                _owned = false;
                _mutex.ReleaseMutex();
            }

            if (_hwndSource != null)
            {
                _hwndSource.RemoveHook(MessageHook);
                _hwndSource = null;
            }
        }

        public void Run(Func<Window> showWindow, string[] args)
        {
            if (_owned)
            {
                // show the main app window
                Window wnd = showWindow();

                // add a hook
                WindowInteropHelper helper = new WindowInteropHelper(wnd);
                if (helper.Handle == null)
                    throw new Exception("Main window must be shown before calling Run");
                
                _hwndSource = HwndSource.FromHwnd(helper.Handle);
                // alternative:
                // HwndSource hwndSource = (HwndSource)PresentationSource.FromDependencyObject(wnd);
                _hwndSource.AddHook(MessageHook);
            }
            else
            {
                BringToFront();
                SendCommandLineArgs(args);
                Application.Current.Shutdown();
            }
        }

        private void BringToFront()
        {
            if (_hWndOther != IntPtr.Zero)
            {
                if (WindowsManagement.IsIconic(_hWndOther) != 0)
                    WindowsManagement.ShowWindowAsync(_hWndOther, WindowsManagement.SW_RESTORE);
                WindowsManagement.SetForegroundWindow(_hWndOther);
            }
        }

        private void SendCommandLineArgs(string[] args)
        {
            if (_hWndOther != IntPtr.Zero)
            {
                IntPtr buffer = IntPtr.Zero;
                IntPtr pcds = IntPtr.Zero;
                MemoryStream stream = null;
                try
                {
                    ArgsPacket packet = new ArgsPacket { AppGuid = _appGuid, Args = args };

                    stream = new MemoryStream();
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, packet);

                    byte[] abyte = stream.ToArray();
                    buffer = Marshal.AllocCoTaskMem(abyte.Length);
                    Marshal.Copy(abyte, 0, buffer, abyte.Length);

                    WindowsManagement.COPYDATASTRUCT cds = new WindowsManagement.COPYDATASTRUCT();
                    cds.dwData = COPYDATA_TYPE_FILENAME;
                    cds.cbData = abyte.Length;
                    cds.lpData = buffer;

                    pcds = Marshal.AllocCoTaskMem(Marshal.SizeOf(cds));
                    Marshal.StructureToPtr(cds, pcds, true);

                    WindowsManagement.SendMessage(_hWndOther, (int)WindowsMessages.WM_COPYDATA, IntPtr.Zero, pcds);

                }
                catch
                { // oh, swallowing block? yes, if you have better ideas extend it
                }
                finally
                {
                    if (buffer != IntPtr.Zero)
                        Marshal.FreeCoTaskMem(buffer);
                    if (pcds != IntPtr.Zero)
                        Marshal.FreeCoTaskMem(pcds);
                    if (stream != null)
                        stream.Close();
                }
            }
        }

        private IntPtr MessageHook(IntPtr hwnd,
                                   int msg,
                                   IntPtr wParam,
                                   IntPtr lParam,
                                   ref bool handled)
        {
            IntPtr ret = IntPtr.Zero;
            handled = false;

            if (msg == (int)WindowsMessages.WM_COPYDATA)
            {
                WindowsManagement.COPYDATASTRUCT cds =
                    (WindowsManagement.COPYDATASTRUCT)Marshal.PtrToStructure(
                    lParam, typeof(WindowsManagement.COPYDATASTRUCT));
                if (cds.dwData == SingleInstance.COPYDATA_TYPE_FILENAME) // extra check if it's us
                {
                    MemoryStream stream = null;
                    try
                    {
                        byte[] abyte = new byte[cds.cbData];
                        Marshal.Copy(cds.lpData, abyte, 0, cds.cbData);
                        stream = new MemoryStream(abyte);

                        BinaryFormatter formatter = new BinaryFormatter();
                        ArgsPacket packet = (ArgsPacket)formatter.Deserialize(stream);

                        if (packet.AppGuid == _appGuid)
                        {
                            // now we know this is us
                            handled = true;

                            if (ArgsRecieved != null)
                                ArgsRecieved(packet.Args);

                            ret = new IntPtr(1);
                        }
                    }
                    catch
                    { // log it or do what you want
                    }
                    finally
                    {
                        if (stream != null)
                            stream.Close();
                    }
                }
            }
            else if (msg == (int)UWM_ARE_YOU_ME)
            {
                ret = (IntPtr)UWM_ARE_YOU_ME;
                handled = true;
            }

            return ret;
        }
    }
}
